package com.digitalized_nepal.localgovernance;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class GoveUpdateAdapter extends RecyclerView.Adapter<GoveUpdateAdapter.SearchViewHolder> {
    RecyclerView recyclerView;
    Context context;
    ArrayList<String> descrip = new ArrayList<>();
    ArrayList<String> imageid = new ArrayList<>();
    ArrayList<String> titile = new ArrayList<>();



    public GoveUpdateAdapter(RecyclerView recyclerView, Context context, ArrayList<String> descrip, ArrayList<String> imageid, ArrayList<String> titile) {
        this.recyclerView = recyclerView;
        this.context = context;
        this.descrip = descrip;
        this.imageid = imageid;
        this.titile = titile;

    }

    @Override
    public GoveUpdateAdapter.SearchViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.governmentupdate, parent, false);
        return new GoveUpdateAdapter.SearchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SearchViewHolder viewHolder, int i) {
      //  holder.full_name.setText(fullNameList.get(position));
        viewHolder.description.setText(descrip.get(i));
        viewHolder.title.setText(titile.get(i));


        Picasso.get().load(imageid.get(i)).into(viewHolder.imageView);
    }




    @Override
    public int getItemCount() {
        return descrip.size();
    }

    public class SearchViewHolder extends RecyclerView.ViewHolder
    {
        TextView title ;
        TextView description ;
        ImageView imageView ;
        TextView sendfeedback;
        public SearchViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.problem_title);
            description = itemView.findViewById(R.id.description_title);
            sendfeedback = itemView.findViewById(R.id.governproject);
            imageView = itemView.findViewById(R.id.governproject);

            sendfeedback.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    Intent callIntent = new Intent(Intent.ACTION_VIEW);
//                    callIntent.setData(Uri.parse("tel:" + mobile));
//                    context.startActivity(callIntent);
                }
            });
        }
    }


}
